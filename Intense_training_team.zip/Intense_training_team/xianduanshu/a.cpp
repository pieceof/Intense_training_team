#include <bits/stdc++.h>

using namespace std;
const int inf = 0x3f3f3f3f;
const int maxn = (int) 1e6 + 7;
typedef long long ll;
#define clr(x) memset(x,0,sizeof(x));

struct rec {
    int l, r, v;
} tree[maxn];

int w[maxn];

void build(int l, int r, int k) {

    tree[k].l = l;
    tree[k].r = r;

    if (l == r) {
        tree[k].v = w[l];
        return;
    }

    int mid = (l + r) / 2;

    build(l, mid, k << 1);
    build(mid + 1, r, k << 1 | 1);

    tree[k].v = tree[k << 1].v + tree[k << 1 | 1].v;

    return;
}

void Add(int k, int n, int x) {
    int mid = (tree[k].l + tree[k].r) / 2;
    tree[k].v += x;
    if (tree[k].l == tree[k].r) {
        return;
    }
    if (mid > n)
        Add(k << 1, n, x);
    else
        Add(k << 1 | 1, n, x);
}


int Que(int k, int l, int r) {

    if (tree[k].l == l && tree[k].r == r) {
        return tree[k].v;
    }

    int mid = (tree[k].l + tree[k].r) / 2;

    if (l <= mid && r > mid) {
        return Que(k << 1, l, mid) + Que(k << 1 | 1, mid + 1, r);
    }
    if (r <= mid) {
        return Que(k << 1, l, r);
    }
    if (l > mid) {
        return Que(k << 1 | 1, l, r);
    }

}

int main() {

#ifndef ONLINE_JUDGE
    freopen("in.txt", "r", stdin);
#endif

    int T, n;
    cin >> T;
    int num = 0;
    while (T--) {

        clr(tree);
        clr(w);
        string str;
        //str.resize(100);
        int a, b;
        printf("Case %d:\n", ++num);

        cin >> n;
        for (int i = 1; i <= n; ++i) {
            cin >> w[i];
        }

        build(1, n, 1);

        while (cin >> str && str != "End" && ~scanf("%d%d", &a, &b)) {

            if (str == "Query") {
                printf("%d\n", Que(1, a, b));
            }

            if (str == "Add") {
                Add(1, a, b);
            }

            if (str == "Sub") {
                Add(1, a, -b);
            }
        }

    }
    return 0;
}