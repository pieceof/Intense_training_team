#include <bits/stdc++.h>
using namespace std;
const int inf = 0x3f3f3f3f;
const int maxn = (int) 1e6+7;
typedef  long long ll;
int main(){

    

    return 0;
}