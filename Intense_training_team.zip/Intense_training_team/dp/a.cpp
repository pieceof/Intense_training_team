#include<bits/stdc++.h>

using namespace std;
const int inf = 0x3f3f3f3f;
const int maxn = (int) 1e6 + 7;
typedef long long ll;

int main() {
    int n, tmp;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {

        scanf("%d", &tmp);
        printf("%d\n", 2 * tmp * tmp - tmp + 1);
    }
    return 0;
}